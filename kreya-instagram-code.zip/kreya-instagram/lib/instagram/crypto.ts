// lib/instagram/crypto.ts
// AES-256-CBC encryption for Instagram access tokens
// Tokens are NEVER stored in plaintext — encrypted before writing to DB
// Decrypted only on the server, only when needed for an API call

import crypto from 'crypto'

const ALGORITHM = 'aes-256-cbc'
const KEY_LENGTH = 32  // 256 bits
const IV_LENGTH  = 16  // 128 bits

/**
 * Derives a 32-byte key from the environment secret.
 * Using scrypt so even if someone gets the derived key,
 * they can't reverse-engineer the master secret.
 */
function getDerivedKey(): Buffer {
  const secret = process.env.TOKEN_ENCRYPTION_KEY
  if (!secret) throw new Error('TOKEN_ENCRYPTION_KEY environment variable is not set')
  // In production this should use a proper KDF with a stored salt
  // For simplicity, using a fixed salt derived from the key itself
  return crypto.scryptSync(secret, 'kreya-ig-token-salt-v1', KEY_LENGTH)
}

/**
 * Encrypts an Instagram access token before storing in Supabase.
 * Returns the encrypted token AND the IV (both stored in DB).
 * The IV is not secret — it just ensures the same token encrypts differently each time.
 */
export function encryptToken(plainToken: string): { encrypted: string; iv: string } {
  const key = getDerivedKey()
  const iv  = crypto.randomBytes(IV_LENGTH)

  const cipher = crypto.createCipheriv(ALGORITHM, key, iv)
  const encrypted = Buffer.concat([
    cipher.update(plainToken, 'utf8'),
    cipher.final(),
  ])

  return {
    encrypted: encrypted.toString('hex'),
    iv: iv.toString('hex'),
  }
}

/**
 * Decrypts a stored token to make an API call.
 * Only called server-side inside route handlers.
 * Never called in client components.
 */
export function decryptToken(encryptedHex: string, ivHex: string): string {
  const key       = getDerivedKey()
  const iv        = Buffer.from(ivHex, 'hex')
  const encrypted = Buffer.from(encryptedHex, 'hex')

  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv)
  const decrypted = Buffer.concat([
    decipher.update(encrypted),
    decipher.final(),
  ])

  return decrypted.toString('utf8')
}
