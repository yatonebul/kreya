// lib/instagram/oauth.ts
// Handles the full OAuth 2.0 flow with Instagram Platform API
// Uses the July 2024 Instagram Direct Login (no Facebook Page required)
// API Version: v24.0 (current stable as of March 2026)

import type { IGTokenResponse, IGUserProfile } from '@/types/instagram'

const IG_API_VERSION = process.env.INSTAGRAM_GRAPH_API_VERSION || 'v24.0'
const IG_AUTH_BASE   = 'https://api.instagram.com'
const IG_GRAPH_BASE  = `https://graph.instagram.com/${IG_API_VERSION}`

// ─── STEP 1: Build OAuth URL ───────────────────────────────────────────────

/**
 * Generates the Instagram OAuth authorization URL.
 * User is redirected here when they click "Connect Instagram" in Kreya.
 *
 * @param state - A cryptographically random string tied to this user's session.
 *                MUST be validated in the callback to prevent CSRF attacks.
 */
export function buildInstagramAuthUrl(state: string): string {
  const params = new URLSearchParams({
    client_id:     process.env.INSTAGRAM_APP_ID!,
    redirect_uri:  process.env.INSTAGRAM_REDIRECT_URI!,
    scope:         'instagram_business_basic,instagram_business_content_publish',
    response_type: 'code',
    state,          // validated in callback route to prevent CSRF
  })

  return `${IG_AUTH_BASE}/oauth/authorize?${params.toString()}`
}

// ─── STEP 2: Exchange code for short-lived token ───────────────────────────

/**
 * Exchanges the authorization code (from the OAuth callback) for a
 * short-lived access token (valid for ~1 hour).
 * Immediately exchanges it for a long-lived token (60 days).
 */
export async function exchangeCodeForTokens(code: string): Promise<{
  accessToken: string
  userId: string
  expiresAt: Date
}> {
  // 2a. Get short-lived token (1 hour)
  const shortLivedRes = await fetch(`${IG_AUTH_BASE}/oauth/access_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id:     process.env.INSTAGRAM_APP_ID!,
      client_secret: process.env.INSTAGRAM_APP_SECRET!,
      grant_type:    'authorization_code',
      redirect_uri:  process.env.INSTAGRAM_REDIRECT_URI!,
      code,
    }),
  })

  if (!shortLivedRes.ok) {
    const err = await shortLivedRes.json()
    throw new Error(`IG token exchange failed: ${err.error_message || JSON.stringify(err)}`)
  }

  const shortLived: IGTokenResponse & { user_id: string } = await shortLivedRes.json()

  // 2b. Immediately exchange for long-lived token (60 days)
  const longLived = await getLongLivedToken(shortLived.access_token)

  // Calculate exact expiry date (subtract 5 days buffer for safety)
  const expiresAt = new Date()
  expiresAt.setSeconds(expiresAt.getSeconds() + (longLived.expires_in ?? 5184000) - 432000)

  return {
    accessToken: longLived.access_token,
    userId:      shortLived.user_id,
    expiresAt,
  }
}

// ─── STEP 3: Long-lived token exchange ────────────────────────────────────

/**
 * Exchanges a short-lived token for a long-lived one (60 days).
 * Called immediately after the initial code exchange.
 */
export async function getLongLivedToken(shortLivedToken: string): Promise<IGTokenResponse & { expires_in: number }> {
  const res = await fetch(
    `${IG_GRAPH_BASE}/access_token?${new URLSearchParams({
      grant_type:    'ig_exchange_token',
      client_secret: process.env.INSTAGRAM_APP_SECRET!,
      access_token:  shortLivedToken,
    })}`,
  )

  if (!res.ok) {
    const err = await res.json()
    throw new Error(`Long-lived token exchange failed: ${JSON.stringify(err)}`)
  }

  return res.json()
}

// ─── STEP 4: Refresh long-lived token ─────────────────────────────────────

/**
 * Refreshes a long-lived token before it expires.
 * Call this when token_expires_at is within 7 days.
 * A token can only be refreshed if it's at least 24 hours old AND not expired.
 *
 * In production: run this as a nightly cron job via Upstash QStash.
 */
export async function refreshLongLivedToken(existingToken: string): Promise<{
  accessToken: string
  expiresAt: Date
}> {
  const res = await fetch(
    `${IG_GRAPH_BASE}/refresh_access_token?${new URLSearchParams({
      grant_type:   'ig_refresh_token',
      access_token: existingToken,
    })}`,
  )

  if (!res.ok) {
    const err = await res.json()
    // If refresh fails, token may be revoked — user needs to reconnect
    throw new Error(`Token refresh failed (user may need to reconnect): ${JSON.stringify(err)}`)
  }

  const data: IGTokenResponse & { expires_in: number } = await res.json()

  const expiresAt = new Date()
  expiresAt.setSeconds(expiresAt.getSeconds() + data.expires_in - 432000) // 5-day buffer

  return { accessToken: data.access_token, expiresAt }
}

// ─── STEP 5: Fetch user profile ────────────────────────────────────────────

/**
 * Fetches the connected Instagram account's profile information.
 * Called after token exchange to store display info in our DB.
 */
export async function fetchInstagramProfile(accessToken: string): Promise<IGUserProfile> {
  const fields = 'id,username,name,profile_picture_url,followers_count,account_type'
  const res = await fetch(
    `${IG_GRAPH_BASE}/me?fields=${fields}&access_token=${accessToken}`,
  )

  if (!res.ok) {
    const err = await res.json()
    throw new Error(`Failed to fetch IG profile: ${JSON.stringify(err)}`)
  }

  return res.json()
}
