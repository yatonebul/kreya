// lib/instagram/publish.ts
// Handles all content publishing to Instagram via the Graph API
// Supports: single image, single video, Reels, carousel (multi-image)
// API uses a 2-step process: create container → publish container

import type { IGMediaContainer, IGPublishResponse } from '@/types/instagram'

const IG_API_VERSION = process.env.INSTAGRAM_GRAPH_API_VERSION || 'v24.0'
const IG_GRAPH_BASE  = `https://graph.instagram.com/${IG_API_VERSION}`

// ─── TYPES ─────────────────────────────────────────────────────────────────

export type PublishImageParams = {
  igUserId:    string
  accessToken: string
  imageUrl:    string   // Must be a publicly accessible URL (Supabase Storage public URL)
  caption:     string
  altText?:    string   // Added March 2025 — accessibility field
}

export type PublishVideoParams = {
  igUserId:    string
  accessToken: string
  videoUrl:    string   // Publicly accessible video URL
  caption:     string
  mediaType:   'REELS' | 'VIDEO'
  shareToFeed?: boolean // For Reels — also show in grid
  thumbOffset?: number  // Millisecond offset for thumbnail frame
}

export type PublishCarouselParams = {
  igUserId:    string
  accessToken: string
  mediaUrls:   string[] // 2–10 images or videos. Mix allowed.
  caption:     string
  mediaType?:  'IMAGE' | 'VIDEO' // type of each item in the carousel
}

// ─── SINGLE IMAGE ──────────────────────────────────────────────────────────

/**
 * Posts a single image to Instagram.
 * Step 1: Create media container
 * Step 2: Publish the container
 *
 * imageUrl MUST be publicly accessible at publish time.
 * Instagram's servers fetch the image directly — it cannot be behind auth.
 * Use Supabase Storage public bucket or a CDN URL.
 */
export async function publishImage(params: PublishImageParams): Promise<string> {
  const { igUserId, accessToken, imageUrl, caption, altText } = params

  // Step 1 — Create the media container
  const containerBody: Record<string, string> = {
    image_url:    imageUrl,
    caption:      caption,
    access_token: accessToken,
  }
  if (altText) containerBody.alt_text = altText  // Added March 2025

  const containerRes = await fetch(
    `${IG_GRAPH_BASE}/${igUserId}/media`,
    {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(containerBody),
    },
  )

  await assertSuccess(containerRes, 'Create image container')
  const container: IGMediaContainer = await containerRes.json()

  // Step 2 — Poll until container is ready, then publish
  await waitForContainerReady(igUserId, container.id, accessToken)

  const mediaId = await publishContainer(igUserId, container.id, accessToken)
  return mediaId
}

// ─── SINGLE VIDEO / REEL ──────────────────────────────────────────────────

/**
 * Posts a video or Reel to Instagram.
 * Video requirements:
 *   - Format: MP4 (H.264 video, AAC audio)
 *   - Max size: 1GB
 *   - Duration: 3s–60s for feed video, 3s–90s for Reels
 *   - Aspect ratio: 9:16 for Reels (recommended)
 */
export async function publishVideo(params: PublishVideoParams): Promise<string> {
  const { igUserId, accessToken, videoUrl, caption, mediaType, shareToFeed, thumbOffset } = params

  const containerBody: Record<string, string | boolean | number> = {
    media_type:   mediaType,
    video_url:    videoUrl,
    caption:      caption,
    access_token: accessToken,
  }
  if (mediaType === 'REELS' && shareToFeed !== undefined) {
    containerBody.share_to_feed = shareToFeed
  }
  if (thumbOffset !== undefined) {
    containerBody.thumb_offset = thumbOffset
  }

  const containerRes = await fetch(
    `${IG_GRAPH_BASE}/${igUserId}/media`,
    {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(containerBody),
    },
  )

  await assertSuccess(containerRes, 'Create video container')
  const container: IGMediaContainer = await containerRes.json()

  // Videos take longer to process — poll up to 5 minutes
  await waitForContainerReady(igUserId, container.id, accessToken, 60, 5000)

  const mediaId = await publishContainer(igUserId, container.id, accessToken)
  return mediaId
}

// ─── CAROUSEL (multi-image or mixed) ──────────────────────────────────────

/**
 * Posts a carousel post (2–10 images/videos) to Instagram.
 * Step 1: Create individual item containers for each media
 * Step 2: Create a carousel container referencing all items
 * Step 3: Publish the carousel container
 */
export async function publishCarousel(params: PublishCarouselParams): Promise<string> {
  const { igUserId, accessToken, mediaUrls, caption, mediaType = 'IMAGE' } = params

  if (mediaUrls.length < 2 || mediaUrls.length > 10) {
    throw new Error('Carousel requires 2–10 media items')
  }

  // Step 1 — Create individual item containers
  const itemContainerIds: string[] = []

  for (const url of mediaUrls) {
    const body: Record<string, string | boolean> = {
      is_carousel_item: true,
      access_token:     accessToken,
    }
    if (mediaType === 'IMAGE') {
      body.image_url = url
    } else {
      body.media_type = 'VIDEO'
      body.video_url  = url
    }

    const res = await fetch(`${IG_GRAPH_BASE}/${igUserId}/media`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    })
    await assertSuccess(res, `Create carousel item container for ${url}`)
    const item: IGMediaContainer = await res.json()
    itemContainerIds.push(item.id)
  }

  // Step 2 — Create carousel container
  const carouselRes = await fetch(`${IG_GRAPH_BASE}/${igUserId}/media`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({
      media_type:   'CAROUSEL',
      caption,
      children:     itemContainerIds.join(','),
      access_token: accessToken,
    }),
  })
  await assertSuccess(carouselRes, 'Create carousel container')
  const carousel: IGMediaContainer = await carouselRes.json()

  // Step 3 — Publish
  await waitForContainerReady(igUserId, carousel.id, accessToken)
  const mediaId = await publishContainer(igUserId, carousel.id, accessToken)
  return mediaId
}

// ─── INTERNALS ─────────────────────────────────────────────────────────────

/**
 * Publishes a ready container.
 * Returns the Instagram media ID of the published post.
 */
async function publishContainer(
  igUserId: string,
  containerId: string,
  accessToken: string,
): Promise<string> {
  const res = await fetch(`${IG_GRAPH_BASE}/${igUserId}/media_publish`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({
      creation_id:  containerId,
      access_token: accessToken,
    }),
  })

  await assertSuccess(res, 'Publish container')
  const data: IGPublishResponse = await res.json()
  return data.id
}

/**
 * Polls the container status until it's FINISHED (ready to publish).
 * Instagram processes images/videos asynchronously after container creation.
 *
 * Statuses: IN_PROGRESS → FINISHED | ERROR | EXPIRED
 * Images: ready in ~1–3 seconds
 * Videos: ready in ~30s–5min depending on size
 */
async function waitForContainerReady(
  igUserId: string,
  containerId: string,
  accessToken: string,
  maxAttempts = 20,
  pollInterval = 2000,
): Promise<void> {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    await sleep(pollInterval)

    const res = await fetch(
      `${IG_GRAPH_BASE}/${containerId}?fields=status_code,status&access_token=${accessToken}`,
    )

    if (!res.ok) continue

    const { status_code } = await res.json()

    if (status_code === 'FINISHED') return
    if (status_code === 'ERROR')    throw new Error('Instagram media container processing failed')
    if (status_code === 'EXPIRED')  throw new Error('Instagram media container expired — re-upload required')
    // IN_PROGRESS — keep polling
  }

  throw new Error(`Container not ready after ${maxAttempts} attempts (${maxAttempts * pollInterval / 1000}s)`)
}

/**
 * Throws a descriptive error if the API response is not OK.
 * Parses Instagram's error format and surfaces the useful message.
 */
async function assertSuccess(res: Response, context: string): Promise<void> {
  if (res.ok) return

  let errorDetail = ''
  try {
    const err = await res.json()
    errorDetail = err.error?.message || JSON.stringify(err)
  } catch {
    errorDetail = `HTTP ${res.status}`
  }

  // Map common Instagram error codes to user-friendly messages
  const errorMap: Record<number, string> = {
    190:  'Access token expired — user needs to reconnect Instagram',
    200:  'Missing permission. App may need re-approval for this action.',
    2207:  'Rate limit hit. Max 50 posts per 24 hours per IG account.',
    9007:  'Content violates Instagram Community Guidelines.',
    36000: 'Video format not supported. Use MP4 H.264.',
    36003: 'Image URL not publicly accessible.',
    36004: 'Video duration out of range (3s–90s for Reels).',
  }

  // Try to extract error code
  const codeMatch = errorDetail.match(/"code"\s*:\s*(\d+)/)
  const code = codeMatch ? parseInt(codeMatch[1]) : 0
  const friendlyMessage = errorMap[code] || errorDetail

  throw new Error(`Instagram API error in [${context}]: ${friendlyMessage}`)
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))
