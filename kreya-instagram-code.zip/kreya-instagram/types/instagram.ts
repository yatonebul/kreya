// types/instagram.ts
// All TypeScript types for the Instagram integration layer

export type InstagramTokens = {
  access_token: string          // AES-256 encrypted before storing in DB
  token_iv: string              // Initialization vector for decryption
  expires_at: string            // ISO date — refresh before this
  instagram_user_id: string     // The IG account ID (e.g. "17841400008460056")
}

export type InstagramAccount = {
  id: string                    // Supabase UUID
  org_id: string                // FK → organizations.id
  instagram_user_id: string     // Native Instagram ID
  username: string              // @handle (no @)
  name: string                  // Display name
  profile_picture_url: string
  followers_count: number
  account_type: 'BUSINESS' | 'CREATOR' | 'PERSONAL'
  is_active: boolean
  token_expires_at: string
  created_at: string
  // access_token is NEVER returned to the client — server only
}

export type InstagramPost = {
  id: string
  org_id: string
  instagram_account_id: string
  caption: string
  media_type: 'IMAGE' | 'VIDEO' | 'REEL' | 'CAROUSEL_ALBUM'
  media_urls: string[]          // Must be publicly accessible URLs
  status: 'pending' | 'published' | 'failed' | 'scheduled'
  instagram_media_id: string | null
  instagram_permalink: string | null
  scheduled_for: string | null
  published_at: string | null
  error_message: string | null
  retry_count: number
  created_at: string
}

export type IGApiError = {
  error: {
    message: string
    type: string
    code: number
    error_subcode?: number
    fbtrace_id: string
  }
}

// What the IG Graph API returns for a user profile
export type IGUserProfile = {
  id: string
  username: string
  name: string
  profile_picture_url: string
  followers_count: number
  account_type: string
}

// Container creation response
export type IGMediaContainer = {
  id: string    // creation_id — used to publish
}

// Publish response
export type IGPublishResponse = {
  id: string    // instagram_media_id of the published post
}

// Token exchange response
export type IGTokenResponse = {
  access_token: string
  token_type: string
  expires_in?: number           // seconds until expiry (long-lived = 5184000 = 60 days)
  user_id?: string
}
