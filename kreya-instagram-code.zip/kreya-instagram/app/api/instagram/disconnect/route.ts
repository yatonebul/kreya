// app/api/instagram/disconnect/route.ts
// Disconnects Instagram — marks account inactive, logs audit event.
// Does NOT delete the row so reconnection history is preserved.
// The encrypted token becomes unreachable (is_active = false).

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: org } = await supabase
    .from('organizations')
    .select('id')
    .eq('owner_id', user.id)
    .single()

  const { data: account } = await supabase
    .from('instagram_accounts')
    .select('id, username')
    .eq('org_id', user.id)
    .eq('is_active', true)
    .single()

  if (!account) {
    return NextResponse.json({ error: 'No active Instagram account found' }, { status: 404 })
  }

  // Mark inactive — keep the row for audit history
  await supabase
    .from('instagram_accounts')
    .update({ is_active: false, disconnected_at: new Date().toISOString() })
    .eq('id', account.id)

  // Audit log
  if (org) {
    await supabase.from('social_audit_log').insert({
      org_id: org.id, user_id: user.id,
      action: 'instagram_disconnected', platform: 'instagram',
      ip_address: req.headers.get('x-forwarded-for'),
    })
  }

  return NextResponse.json({ status: 'disconnected', handle: `@${account.username}` })
}
