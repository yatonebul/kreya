// app/api/instagram/callback/route.ts
// STEP 2 of the OAuth flow.
// Instagram redirects the user back here after they authorize Kreya.
// URL will contain: ?code=AUTH_CODE&state=RANDOM_STATE
// OR on error: ?error=access_denied&error_reason=user_denied
//
// This is the most security-critical route in the integration.
// Every step is validated before anything is stored.

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { exchangeCodeForTokens, fetchInstagramProfile } from '@/lib/instagram/oauth'
import { encryptToken } from '@/lib/instagram/crypto'
import { Redis } from '@upstash/redis'

const redis = new Redis({
  url:   process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const code  = searchParams.get('code')
  const state = searchParams.get('state')
  const error = searchParams.get('error')

  const redirect = (path: string) =>
    NextResponse.redirect(new URL(path, req.url))

  // ── Handle user denying the permission ───────────────────────────────────
  if (error) {
    const reason = searchParams.get('error_reason') || error
    console.warn('[IG OAuth] User denied or error occurred:', reason)
    return redirect(`/dashboard/connections?error=${encodeURIComponent(reason)}`)
  }

  // ── Validate required params ──────────────────────────────────────────────
  if (!code || !state) {
    return redirect('/dashboard/connections?error=invalid_callback')
  }

  // ── 1. Validate state (CSRF protection) ────────────────────────────────
  // Look up the state in Redis — must match what we stored in /api/instagram/oauth
  const userId = await redis.get<string>(`ig_oauth_state:${state}`)

  if (!userId) {
    // State not found or expired (>10 min) or already used
    console.warn('[IG OAuth] Invalid or expired state token:', state.slice(0, 8) + '...')
    return redirect('/dashboard/connections?error=state_mismatch')
  }

  // Delete the state immediately — it's single-use
  await redis.del(`ig_oauth_state:${state}`)

  // ── 2. Verify the Supabase session matches the userId from state ──────────
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user || user.id !== userId) {
    console.warn('[IG OAuth] Session mismatch — possible session hijack attempt')
    return redirect('/login?error=session_mismatch')
  }

  // ── 3. Exchange authorization code for tokens ─────────────────────────────
  let tokens: Awaited<ReturnType<typeof exchangeCodeForTokens>>
  try {
    tokens = await exchangeCodeForTokens(code)
  } catch (err) {
    console.error('[IG OAuth] Token exchange failed:', err)
    return redirect(`/dashboard/connections?error=token_exchange_failed`)
  }

  // ── 4. Fetch Instagram profile info ───────────────────────────────────────
  let profile: Awaited<ReturnType<typeof fetchInstagramProfile>>
  try {
    profile = await fetchInstagramProfile(tokens.accessToken)
  } catch (err) {
    console.error('[IG OAuth] Profile fetch failed:', err)
    return redirect('/dashboard/connections?error=profile_fetch_failed')
  }

  // ── 5. Encrypt the access token before storing ────────────────────────────
  // The raw token is NEVER written to the database.
  // Even a full DB dump would reveal only the encrypted blob.
  const { encrypted: encryptedToken, iv: tokenIv } = encryptToken(tokens.accessToken)

  // ── 6. Get the user's organization ───────────────────────────────────────
  const { data: org } = await supabase
    .from('organizations')
    .select('id')
    .eq('owner_id', user.id)
    .single()

  if (!org) {
    return redirect('/dashboard/connections?error=org_not_found')
  }

  // ── 7. Upsert the Instagram account ───────────────────────────────────────
  // Upsert handles: first connect, reconnect after disconnect, token refresh
  const { error: dbError } = await supabase
    .from('instagram_accounts')
    .upsert(
      {
        org_id:                user.id,           // scoped to this user
        instagram_user_id:     profile.id,
        username:              profile.username,
        name:                  profile.name,
        profile_picture_url:   profile.profile_picture_url,
        followers_count:       profile.followers_count,
        account_type:          profile.account_type,
        encrypted_token:       encryptedToken,    // AES-256 encrypted
        token_iv:              tokenIv,            // IV for decryption
        token_expires_at:      tokens.expiresAt.toISOString(),
        is_active:             true,
        connected_at:          new Date().toISOString(),
      },
      {
        onConflict: 'org_id,instagram_user_id',   // update if reconnecting same account
      },
    )

  if (dbError) {
    console.error('[IG OAuth] DB upsert failed:', dbError)
    return redirect('/dashboard/connections?error=db_error')
  }

  // ── 8. Audit log ─────────────────────────────────────────────────────────
  await supabase.from('social_audit_log').insert({
    org_id:     org.id,
    user_id:    user.id,
    action:     'instagram_connected',
    platform:   'instagram',
    ip_address: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip'),
  })

  // ── 9. Success ────────────────────────────────────────────────────────────
  return redirect(
    `/dashboard/connections?success=instagram_connected&handle=${encodeURIComponent('@' + profile.username)}`
  )
}
