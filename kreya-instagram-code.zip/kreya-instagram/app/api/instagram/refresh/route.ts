// app/api/instagram/refresh/route.ts
// Nightly cron job — refreshes all tokens expiring within 7 days.
// Triggered by Upstash QStash on a schedule: 0 3 * * * (3am daily)
// Protected by QStash's signing key — cannot be called by anyone else.

import { NextRequest, NextResponse } from 'next/server'
import { verifySignatureAppRouter } from '@upstash/qstash/nextjs'
import { createServerClient } from '@supabase/ssr'
import { decryptToken } from '@/lib/instagram/crypto'
import { encryptToken } from '@/lib/instagram/crypto'
import { refreshLongLivedToken } from '@/lib/instagram/oauth'
import { cookies } from 'next/headers'

async function handler(req: NextRequest) {
  // Use service role key here — this runs as a system process, not a user
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!, // service role bypasses RLS — only use server-side
    { cookies: { getAll: () => [], setAll: () => {} } }
  )

  // Find all accounts with tokens expiring in the next 7 days
  const sevenDaysFromNow = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()

  const { data: accounts, error } = await supabase
    .from('instagram_accounts')
    .select('id, org_id, username, encrypted_token, token_iv, token_expires_at')
    .eq('is_active', true)
    .lt('token_expires_at', sevenDaysFromNow)

  if (error) {
    console.error('[IG Refresh Cron] DB query failed:', error)
    return NextResponse.json({ error: 'DB query failed' }, { status: 500 })
  }

  const results = { refreshed: 0, failed: 0, errors: [] as string[] }

  for (const account of accounts ?? []) {
    try {
      const rawToken = decryptToken(account.encrypted_token, account.token_iv)
      const { accessToken, expiresAt } = await refreshLongLivedToken(rawToken)
      const { encrypted, iv } = encryptToken(accessToken)

      await supabase
        .from('instagram_accounts')
        .update({ encrypted_token: encrypted, token_iv: iv, token_expires_at: expiresAt.toISOString() })
        .eq('id', account.id)

      results.refreshed++
      console.log(`[IG Refresh] ✓ @${account.username}`)
    } catch (err: any) {
      results.failed++
      results.errors.push(`@${account.username}: ${err.message}`)
      console.error(`[IG Refresh] ✗ @${account.username}:`, err.message)

      // If token is dead (revoked by user from IG settings), mark inactive
      if (err.message.includes('token expired') || err.message.includes('reconnect')) {
        await supabase
          .from('instagram_accounts')
          .update({ is_active: false })
          .eq('id', account.id)

        // TODO: Send user a notification to reconnect
        // await sendWhatsAppAlert(account.org_id, 'Your Instagram connection expired. Reconnect at kreya.ai/dashboard/connections')
      }
    }
  }

  return NextResponse.json({
    processed: accounts?.length ?? 0,
    ...results,
    timestamp: new Date().toISOString(),
  })
}

// Wrap with QStash signature verification — blocks unauthorized calls
export const POST = verifySignatureAppRouter(handler)
