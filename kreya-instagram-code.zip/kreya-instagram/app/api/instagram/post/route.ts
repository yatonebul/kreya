// app/api/instagram/post/route.ts
// The main posting endpoint — called when Kreya AI content is approved.
// Supports: single image, video, Reels, and carousel posts.
//
// Security:
// - Auth check on every request (getUser() validates JWT with Supabase servers)
// - Plan limit enforcement (free = 10 posts/month, pro = 200)
// - Rate limit via Upstash Redis (50 posts per 24h per IG account, enforced by us before hitting Meta)
// - Token decrypted server-side only, never sent to client

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { decryptToken } from '@/lib/instagram/crypto'
import { refreshLongLivedToken } from '@/lib/instagram/oauth'
import { encryptToken } from '@/lib/instagram/crypto'
import { publishImage, publishVideo, publishCarousel } from '@/lib/instagram/publish'
import { Redis } from '@upstash/redis'
import { Ratelimit } from '@upstash/ratelimit'

const redis = new Redis({
  url:   process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

// Rate limit: 25 posts per 24 hours per Kreya user
// (Instagram's hard limit is 50/24h per IG account — we stay well below)
const ratelimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(25, '24 h'),
  prefix:  'kreya:ig:post',
})

export async function POST(req: NextRequest) {
  // ── 1. Auth ───────────────────────────────────────────────────────────────
  const supabase = await createClient()
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  // ── 2. Parse & validate request body ─────────────────────────────────────
  let body: {
    caption:    string
    mediaType:  'IMAGE' | 'VIDEO' | 'REEL' | 'CAROUSEL'
    mediaUrls:  string[]
    altText?:   string
    shareToFeed?: boolean
  }

  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const { caption, mediaType, mediaUrls, altText, shareToFeed } = body

  // Validate
  if (!caption || typeof caption !== 'string') {
    return NextResponse.json({ error: 'caption is required' }, { status: 400 })
  }
  if (caption.length > 2200) {
    return NextResponse.json({ error: 'Caption exceeds 2200 character limit' }, { status: 400 })
  }
  if (!mediaUrls || !Array.isArray(mediaUrls) || mediaUrls.length === 0) {
    return NextResponse.json({ error: 'mediaUrls array is required' }, { status: 400 })
  }
  if (mediaType === 'CAROUSEL' && (mediaUrls.length < 2 || mediaUrls.length > 10)) {
    return NextResponse.json({ error: 'Carousel requires 2–10 media URLs' }, { status: 400 })
  }

  // ── 3. Rate limit check ───────────────────────────────────────────────────
  const { success: withinLimit, remaining, reset } = await ratelimit.limit(user.id)

  if (!withinLimit) {
    const resetDate = new Date(reset)
    return NextResponse.json(
      {
        error: 'Daily posting limit reached',
        detail: `You've reached the 25 posts per day limit. Resets at ${resetDate.toLocaleTimeString()}.`,
        resetAt: reset,
      },
      {
        status: 429,
        headers: { 'X-RateLimit-Reset': reset.toString() },
      },
    )
  }

  // ── 4. Get plan and enforce monthly limits ────────────────────────────────
  const { data: org } = await supabase
    .from('organizations')
    .select('id, plan, monthly_ai_posts_used')
    .eq('owner_id', user.id)
    .single()

  if (!org) {
    return NextResponse.json({ error: 'Organization not found' }, { status: 404 })
  }

  const limits: Record<string, number> = { free: 10, pro: 200, agency: 999999 }
  const monthlyLimit = limits[org.plan] ?? 10

  if (org.monthly_ai_posts_used >= monthlyLimit) {
    return NextResponse.json(
      {
        error: 'Monthly post limit reached',
        plan:  org.plan,
        limit: monthlyLimit,
        used:  org.monthly_ai_posts_used,
        upgradeUrl: '/dashboard/settings/billing',
      },
      { status: 402 },  // Payment Required
    )
  }

  // ── 5. Get the user's Instagram account ──────────────────────────────────
  const { data: igAccount } = await supabase
    .from('instagram_accounts')
    .select('id, instagram_user_id, username, encrypted_token, token_iv, token_expires_at, is_active')
    .eq('org_id', user.id)
    .eq('is_active', true)
    .single()

  if (!igAccount) {
    return NextResponse.json(
      { error: 'No active Instagram account connected', connectUrl: '/dashboard/connections' },
      { status: 400 },
    )
  }

  // ── 6. Decrypt the access token (server-side only) ────────────────────────
  let accessToken: string
  try {
    accessToken = decryptToken(igAccount.encrypted_token, igAccount.token_iv)
  } catch (err) {
    console.error('[IG Post] Token decryption failed for user:', user.id)
    return NextResponse.json({ error: 'Token decryption failed — please reconnect Instagram' }, { status: 500 })
  }

  // ── 7. Proactively refresh token if expiring within 7 days ───────────────
  const expiresAt = new Date(igAccount.token_expires_at)
  const sevenDaysFromNow = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)

  if (expiresAt < sevenDaysFromNow) {
    try {
      const refreshed = await refreshLongLivedToken(accessToken)
      accessToken = refreshed.accessToken  // use the new token for this request

      // Save the new encrypted token to DB
      const { encrypted: newEnc, iv: newIv } = encryptToken(refreshed.accessToken)
      await supabase
        .from('instagram_accounts')
        .update({
          encrypted_token:  newEnc,
          token_iv:         newIv,
          token_expires_at: refreshed.expiresAt.toISOString(),
        })
        .eq('id', igAccount.id)

      console.log('[IG Post] Token proactively refreshed for user:', user.id)
    } catch (refreshErr) {
      // Don't fail the post — just log and continue with existing token
      // It's still valid, just not refreshed
      console.warn('[IG Post] Proactive token refresh failed (non-critical):', refreshErr)
    }
  }

  // ── 8. Publish the content ────────────────────────────────────────────────
  let instagramMediaId: string

  try {
    if (mediaType === 'IMAGE') {
      instagramMediaId = await publishImage({
        igUserId:    igAccount.instagram_user_id,
        accessToken,
        imageUrl:    mediaUrls[0],
        caption,
        altText,
      })
    } else if (mediaType === 'VIDEO') {
      instagramMediaId = await publishVideo({
        igUserId:    igAccount.instagram_user_id,
        accessToken,
        videoUrl:    mediaUrls[0],
        caption,
        mediaType:   'VIDEO',
      })
    } else if (mediaType === 'REEL') {
      instagramMediaId = await publishVideo({
        igUserId:    igAccount.instagram_user_id,
        accessToken,
        videoUrl:    mediaUrls[0],
        caption,
        mediaType:   'REELS',
        shareToFeed: shareToFeed ?? true,
      })
    } else if (mediaType === 'CAROUSEL') {
      instagramMediaId = await publishCarousel({
        igUserId:   igAccount.instagram_user_id,
        accessToken,
        mediaUrls,
        caption,
      })
    } else {
      return NextResponse.json({ error: `Unsupported mediaType: ${mediaType}` }, { status: 400 })
    }
  } catch (publishErr: any) {
    console.error('[IG Post] Publish failed:', publishErr.message)

    // Save failed post record for retry logic
    await supabase.from('instagram_posts').insert({
      org_id:               org.id,
      instagram_account_id: igAccount.id,
      caption,
      media_type:           mediaType,
      media_urls:           mediaUrls,
      status:               'failed',
      error_message:        publishErr.message,
      retry_count:          0,
    })

    // Map error to user-friendly response
    if (publishErr.message.includes('token expired') || publishErr.message.includes('190')) {
      return NextResponse.json(
        { error: 'Instagram token expired. Please reconnect your account.', reconnectUrl: '/api/instagram/oauth' },
        { status: 401 },
      )
    }
    if (publishErr.message.includes('rate limit') || publishErr.message.includes('2207')) {
      return NextResponse.json(
        { error: 'Instagram rate limit hit. Max 50 posts per 24 hours per account.' },
        { status: 429 },
      )
    }

    return NextResponse.json(
      { error: 'Failed to publish to Instagram', detail: publishErr.message },
      { status: 502 },
    )
  }

  // ── 9. Save successful post to our database ───────────────────────────────
  const { data: savedPost } = await supabase
    .from('instagram_posts')
    .insert({
      org_id:                org.id,
      instagram_account_id:  igAccount.id,
      caption,
      media_type:            mediaType,
      media_urls:            mediaUrls,
      status:                'published',
      instagram_media_id:    instagramMediaId,
      instagram_permalink:   `https://www.instagram.com/p/${instagramMediaId}/`,
      published_at:          new Date().toISOString(),
    })
    .select('id')
    .single()

  // ── 10. Increment monthly usage counter ───────────────────────────────────
  await supabase
    .from('organizations')
    .update({ monthly_ai_posts_used: org.monthly_ai_posts_used + 1 })
    .eq('id', org.id)

  // ── 11. Audit log ─────────────────────────────────────────────────────────
  await supabase.from('social_audit_log').insert({
    org_id:   org.id,
    user_id:  user.id,
    action:   'instagram_post_published',
    platform: 'instagram',
    post_id:  savedPost?.id,
    ip_address: req.headers.get('x-forwarded-for'),
  })

  // ── 12. Return success ────────────────────────────────────────────────────
  return NextResponse.json({
    status:             'published',
    instagramMediaId,
    permalink:          `https://www.instagram.com/p/${instagramMediaId}/`,
    postedAs:           `@${igAccount.username}`,
    postsRemainingToday: remaining,
    monthlyUsed:        org.monthly_ai_posts_used + 1,
    monthlyLimit,
  })
}
