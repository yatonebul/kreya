// app/api/instagram/status/route.ts
// Returns the current Instagram connection status for the authenticated user.
// Called by the Connections page to show live account info.
// Never returns the encrypted token — only metadata.

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(req: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: account } = await supabase
    .from('instagram_accounts')
    .select(`
      id, username, name, profile_picture_url, followers_count,
      account_type, is_active, token_expires_at, connected_at
    `)
    // encrypted_token and token_iv are deliberately NOT selected
    .eq('org_id', user.id)
    .order('connected_at', { ascending: false })
    .limit(1)
    .maybeSingle()

  if (!account || !account.is_active) {
    return NextResponse.json({ connected: false })
  }

  const expiresAt = new Date(account.token_expires_at)
  const daysUntilExpiry = Math.floor((expiresAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24))

  return NextResponse.json({
    connected: true,
    username:            account.username,
    name:                account.name,
    profilePictureUrl:   account.profile_picture_url,
    followersCount:      account.followers_count,
    accountType:         account.account_type,
    connectedAt:         account.connected_at,
    tokenExpiresAt:      account.token_expires_at,
    tokenHealthy:        daysUntilExpiry > 7,
    tokenDaysRemaining:  daysUntilExpiry,
    tokenWarning:        daysUntilExpiry <= 7 ? `Token expires in ${daysUntilExpiry} days` : null,
  })
}
