// app/api/instagram/oauth/route.ts
// STEP 1 of the OAuth flow.
// User clicks "Connect Instagram" → Kreya calls this route →
// This route generates a secure state token, stores it in Redis,
// and redirects the user to Instagram's authorization page.

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { buildInstagramAuthUrl } from '@/lib/instagram/oauth'
import { Redis } from '@upstash/redis'
import crypto from 'crypto'

const redis = new Redis({
  url:   process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
})

export async function GET(req: NextRequest) {
  // ── 1. Verify the user is authenticated ──────────────────────────────────
  const supabase = await createClient()
  const { data: { user }, error } = await supabase.auth.getUser()

  if (error || !user) {
    return NextResponse.redirect(new URL('/login?reason=auth_required', req.url))
  }

  // ── 2. Check if user already has Instagram connected ─────────────────────
  const { data: existing } = await supabase
    .from('instagram_accounts')
    .select('id, username, is_active')
    .eq('org_id', user.id)
    .eq('is_active', true)
    .maybeSingle()

  if (existing) {
    // Already connected — redirect back to connections page with info
    return NextResponse.redirect(
      new URL(`/dashboard/connections?info=already_connected&handle=${existing.username}`, req.url)
    )
  }

  // ── 3. Generate cryptographically secure state token ─────────────────────
  // This prevents CSRF attacks. The state must match exactly in the callback.
  const state = crypto.randomBytes(32).toString('hex')

  // Store state in Redis for 10 minutes (OAuth flows shouldn't take longer)
  // Key format: ig_oauth_state:{state} → userId
  await redis.set(
    `ig_oauth_state:${state}`,
    user.id,
    { ex: 600 }  // 600 seconds = 10 minutes
  )

  // ── 4. Redirect user to Instagram OAuth ──────────────────────────────────
  const authUrl = buildInstagramAuthUrl(state)

  return NextResponse.redirect(authUrl)
}
