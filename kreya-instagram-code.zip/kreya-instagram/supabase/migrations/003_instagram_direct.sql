-- =============================================================
-- supabase/migrations/003_instagram_direct.sql
-- Run in: Supabase Dashboard → SQL Editor → New query
-- =============================================================

-- Instagram accounts table
-- One row per connected IG account per org.
-- Encrypted token stored here — never decrypted on the client.
CREATE TABLE instagram_accounts (
  id                    UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id                UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  instagram_user_id     TEXT NOT NULL,
  username              TEXT NOT NULL,
  name                  TEXT,
  profile_picture_url   TEXT,
  followers_count       INT DEFAULT 0,
  account_type          TEXT CHECK (account_type IN ('BUSINESS','CREATOR','PERSONAL')),
  is_active             BOOLEAN DEFAULT TRUE,

  -- Encrypted token (AES-256-CBC) — NEVER store plaintext
  encrypted_token       TEXT NOT NULL,
  token_iv              TEXT NOT NULL,     -- Initialization vector for decryption
  token_expires_at      TIMESTAMPTZ NOT NULL,

  connected_at          TIMESTAMPTZ DEFAULT NOW(),
  disconnected_at       TIMESTAMPTZ,

  UNIQUE (org_id, instagram_user_id)       -- prevent duplicate connections
);

-- Instagram posts table
-- Tracks every post attempt — success or failure.
-- Used for history, analytics, retry logic, and audit trail.
CREATE TABLE instagram_posts (
  id                    UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id                UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  instagram_account_id  UUID NOT NULL REFERENCES instagram_accounts(id),

  caption               TEXT NOT NULL,
  media_type            TEXT NOT NULL CHECK (media_type IN ('IMAGE','VIDEO','REEL','CAROUSEL')),
  media_urls            TEXT[] NOT NULL,

  status                TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','published','failed','scheduled')),

  instagram_media_id    TEXT,             -- returned by IG after successful publish
  instagram_permalink   TEXT,             -- https://www.instagram.com/p/XXX/

  scheduled_for         TIMESTAMPTZ,      -- null = post immediately
  published_at          TIMESTAMPTZ,
  error_message         TEXT,
  retry_count           INT DEFAULT 0,
  last_retry_at         TIMESTAMPTZ,

  created_at            TIMESTAMPTZ DEFAULT NOW()
);

-- Monthly usage counter on organizations
-- Reset at the start of each billing period.
ALTER TABLE organizations
  ADD COLUMN IF NOT EXISTS monthly_ai_posts_used INT DEFAULT 0,
  ADD COLUMN IF NOT EXISTS monthly_reset_at      TIMESTAMPTZ DEFAULT NOW();

-- ── INDEXES ──────────────────────────────────────────────────────
-- Token expiry index — used by nightly refresh cron job
CREATE INDEX idx_ig_accounts_expires   ON instagram_accounts (token_expires_at)
  WHERE is_active = TRUE;

-- Active connections lookup — hot path for every post
CREATE INDEX idx_ig_accounts_active    ON instagram_accounts (org_id, is_active);

-- Post history by org
CREATE INDEX idx_ig_posts_org          ON instagram_posts (org_id, created_at DESC);
CREATE INDEX idx_ig_posts_status       ON instagram_posts (status, scheduled_for)
  WHERE status = 'scheduled';

-- ── ROW LEVEL SECURITY ────────────────────────────────────────────
ALTER TABLE instagram_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE instagram_posts    ENABLE ROW LEVEL SECURITY;

-- Users can only read their own connected accounts
CREATE POLICY "Users see own IG accounts"
  ON instagram_accounts FOR SELECT
  USING (org_id = auth.uid());

-- Users can only read their own posts
CREATE POLICY "Users see own IG posts"
  ON instagram_posts FOR SELECT
  USING (org_id = auth.uid());

-- Insert/update is done by server-side API routes using service role key
-- (service role bypasses RLS — only used server-side, never in client)
-- No client-side INSERT/UPDATE policies needed.

-- ── AUDIT LOG ─────────────────────────────────────────────────────
-- Already created in previous migration — just add the new action types:
-- instagram_connected | instagram_disconnected | instagram_post_published
-- instagram_post_failed | instagram_token_refreshed
